#!/usr/bin/env python
# coding: utf-8

# Nama: Mulad Sariro Yekti Handayani Arum
# NIM: 21060120130086

# In[13]:


import numpy as np
import matplotlib.pyplot as plt

# Sigmoid Function
def act(x):
    return 1/(1+np.exp(-x))

# datasets
x = np.array([[0, 0, 0], [0, 1, 0], [1, 0, 1], [1, 1, 1]])
y = np.array([[0, 1, 1, 0]]).T     # xor

# parameters
input_size = x.shape[1] # original input + bias
hidden_size = 4
output_size = 1
alpha = 0.1    # learning rate

# weights
w1 = np.random.randn(input_size, hidden_size)
w2 = np.random.randn(hidden_size, output_size)

# list nilai loss dan epoch
losses = []
epochs = []

for i in range(10000):
    # forward propagation
    z1 = np.dot(x, w1)
    a1 = act(z1)
    z2 = np.dot(a1, w2)
    Y = act(z2)

    # menghitung loss
    loss = np.mean(np.square(y - Y))
    losses.append(loss)
    epochs.append(i)

    # backward propagation
    delta2 = (Y - y) * (Y * (1 - Y))
    delta1 = np.dot(delta2, w2.T) * (a1 * (1 - a1))
    w2 -= alpha * np.dot(a1.T, delta2)
    w1 -= alpha * np.dot(x.T, delta1)

# test
z1 = np.dot(x, w1)
a1 = act(z1)
z2 = np.dot(a1, w2)
Y = act(z2)
print("Output after training...")
print(Y)

plt.plot(epochs, losses)
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.title('Perubahan loss selama epoch')
plt.show()

prediction = np.round(output)
print("Prediksi Output:")
print(prediction)


# In[ ]:




