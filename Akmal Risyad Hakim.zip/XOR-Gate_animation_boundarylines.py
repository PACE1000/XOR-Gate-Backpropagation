import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# Inisialisasi tabel kebenaran
inputs = np.array([[0,0],[0,1],[1,0],[1,1]])
expected_output = np.array([[0],[1],[1],[0]])

# Buat fungsi sigmoid dan turunannya
def sigmoid (x):
    return 1/(1 + np.exp(-x))

def sigmoid_derivative(x):
    return x * (1 - x)

def calculate_error(y, y_hat):
    return 0.5 * np.mean((y - y_hat)**2)

# Berdasarkan ilustrasi gerbang XOR
inputLayer = 2
hiddenLayer = 2
outputLayer = 1

# Inisialisasi weight dan bias dengan nilai random
hidden_weights = np.random.uniform(size=(inputLayer,hiddenLayer))
hidden_bias =np.random.uniform(size=(1,hiddenLayer))

output_weights = np.random.uniform(size=(hiddenLayer,outputLayer))
output_bias = np.random.uniform(size=(1,outputLayer))

print("Weight awal untuk hidden layer: ",end='')
print(*hidden_weights)
print("Bias awal untuk hidden layer: ",end='')
print(*hidden_bias)
print("Weight awal untuk output layer: ",end='')
print(*output_weights)
print("Bias awal untuk output layer: ",end='')
print(*output_bias)
print("\n")

# Buat list untuk tiap perubahannya
error_changes = []
w11_changes = []
w12_changes = []
w21_changes = []
w22_changes = []
w31_changes = []
w32_changes = []
b1_changes = []
b2_changes = []
b3_changes = []

# Tentukan learning rate dan epoch
lr = 0.1
epoch = 10000

# Training algorithm
for g in range(epoch):
	# Forward pass
	hidden_layer_activation = np.dot(inputs,hidden_weights)
	hidden_layer_activation += hidden_bias
	hidden_layer_output = sigmoid(hidden_layer_activation)

	output_layer_activation = np.dot(hidden_layer_output,output_weights)
	output_layer_activation += output_bias
	predicted_output = sigmoid(output_layer_activation)

	# Hitung nilai error
	error = calculate_error(expected_output, predicted_output)
	error_changes.append(error)

	# Backward pass
	delta_output = expected_output - predicted_output
	delta_predicted_output = delta_output * sigmoid_derivative(predicted_output)
	
	error_hidden_layer = delta_predicted_output.dot(output_weights.T)
	delta_hidden_layer = error_hidden_layer * sigmoid_derivative(hidden_layer_output)

	# Ubah nilai weight and bias
	output_weights += hidden_layer_output.T.dot(delta_predicted_output) * lr
	output_bias += np.sum(delta_predicted_output,axis=0,keepdims=True) * lr
	hidden_weights += inputs.T.dot(delta_hidden_layer) * lr
	hidden_bias += np.sum(delta_hidden_layer,axis=0,keepdims=True) * lr

	# Simpan perubahan ke list yang tersedia
	w11_changes.append(hidden_weights[0][0])
	w12_changes.append(hidden_weights[0][1])
	w21_changes.append(hidden_weights[1][0])
	w22_changes.append(hidden_weights[1][1])
	w31_changes.append(output_weights[0][0])
	w32_changes.append(output_weights[1][0])
	b1_changes.append(hidden_bias[0][0])
	b2_changes.append(hidden_bias[0][1])
	b3_changes.append(output_bias[0][0])

print("Weight akhir untuk hidden layer: ",end='')
print(*hidden_weights)
print("Bias akhir untuk hidden layer: ",end='')
print(*hidden_bias)
print("Weight akhir untuk output layer: ",end='')
print(*output_weights)
print("Bias akhir untuk output layer: ",end='')
print(*output_bias)

print("\nKeluaran dari neural network setelah", epoch, "epoch: ",end='')
print(*predicted_output)

# Create the figure and axis for the plot
fig, axs = plt.subplots()

# Plot the original data points
scatter = axs.scatter(inputs[:, 0], inputs[:, 1], c=expected_output, cmap='viridis')
axs.set_xlim(-0.5, 1.5)
axs.set_ylim(-0.5, 1.5)
axs.set_xlabel('Input 1')
axs.set_ylabel('Input 2')
axs.set_title('Visualisasi Gradient Descent')

# Plot the initial decision boundary lines
line, = axs.plot([], [], 'r-', label='Decision Boundary 1')
line2, = axs.plot([], [], 'b-', label='Decision Boundary 2')
axs.legend()

# Update function for the animation
def update_plot(i):
    current_w11 = w11_changes[i]
    current_w12 = w12_changes[i]
    current_w21 = w21_changes[i]
    current_w22 = w22_changes[i]
    current_w31 = w31_changes[i]
    current_w32 = w32_changes[i]
    current_b1 = b1_changes[i]
    current_b2 = b2_changes[i]
    current_b3 = b3_changes[i]

    x = np.arange(len(w11_changes))
    y1 = -(current_w11 * x + current_w12 * current_b1 + current_w21 * current_b2 + current_w31 * current_b3) / (current_w22 * current_w32)
    y2 = -(current_w11 * x + current_w12 * current_b1 + current_w21 * current_b2 + current_w31 * current_b3 - 1) / (current_w22 * current_w32)

    line.set_data(x, y1)
    line2.set_data(x, y2)

    return line, line2

# Create the animation
ani = animation.FuncAnimation(fig, update_plot, frames=len(w11_changes), interval=1, blit=True)

# Show the plot
plt.show()